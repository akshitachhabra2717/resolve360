-- ResolveDesk 360 initial schema. Apply only after reviewing for your organization's tenancy model.
create extension if not exists pgcrypto;

create type public.app_role as enum ('employee', 'agent', 'manager', 'admin');
create type public.incident_severity as enum ('critical', 'high', 'medium', 'low');
create type public.incident_status as enum ('open', 'investigating', 'pending_approval', 'resolved', 'closed');
create type public.incident_category as enum ('api_errors','database_errors','data_errors','authentication','network','deployment','configuration','performance','infrastructure','integration');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  created_at timestamptz not null default now()
);
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  organization_id uuid references public.organizations(id) on delete restrict,
  display_name text not null default 'User' check (char_length(display_name) <= 120),
  role public.app_role not null default 'employee',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_org_idx on public.profiles(organization_id);

create table public.incidents (
  id uuid primary key default gen_random_uuid(),
  incident_key text unique not null default ('RD-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 8))),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  created_by uuid not null references auth.users(id) on delete restrict,
  assigned_to uuid references public.profiles(id) on delete set null,
  title text not null check (char_length(title) between 3 and 180),
  description text not null check (char_length(description) between 1 and 5000),
  service text not null check (char_length(service) between 1 and 120),
  category public.incident_category not null,
  severity public.incident_severity not null default 'medium',
  status public.incident_status not null default 'open',
  source text not null default 'manual' check (source in ('manual','sentry','github','jira','other')),
  detected_at timestamptz not null default now(),
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index incidents_org_status_idx on public.incidents(organization_id, status, detected_at desc);
create index incidents_org_severity_idx on public.incidents(organization_id, severity, detected_at desc);
create index incidents_assigned_to_idx on public.incidents(assigned_to);

create table public.incident_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  incident_id uuid not null references public.incidents(id) on delete restrict,
  actor_id uuid references auth.users(id) on delete set null,
  event_type text not null check (char_length(event_type) between 1 and 80),
  title text not null check (char_length(title) between 1 and 180),
  detail text not null default '' check (char_length(detail) <= 4000),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index incident_events_incident_time_idx on public.incident_events(incident_id, created_at desc);

create table public.diagnostic_findings (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  incident_id uuid not null references public.incidents(id) on delete restrict,
  created_by uuid references auth.users(id) on delete set null,
  cause text not null check (char_length(cause) between 1 and 1200),
  confidence text not null check (confidence in ('low','medium','high')),
  supporting_evidence jsonb not null default '[]'::jsonb,
  contradictory_evidence jsonb not null default '[]'::jsonb,
  next_check text not null default '' check (char_length(next_check) <= 1500),
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.evidence_references (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  incident_id uuid not null references public.incidents(id) on delete restrict,
  source_type text not null check (char_length(source_type) <= 80),
  source_reference text not null check (char_length(source_reference) between 1 and 1000),
  event_at timestamptz,
  redacted_summary text not null default '' check (char_length(redacted_summary) <= 3000),
  created_at timestamptz not null default now()
);

create table public.troubleshooting_steps (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  incident_id uuid not null references public.incidents(id) on delete restrict,
  step_order integer not null check (step_order > 0),
  title text not null check (char_length(title) between 1 and 180),
  detail text not null check (char_length(detail) <= 3000),
  risk text not null check (risk in ('low','medium','high')),
  expected_result text not null default '' check (char_length(expected_result) <= 1500),
  status text not null default 'proposed' check (status in ('proposed','approved','running','passed','failed','skipped')),
  created_at timestamptz not null default now(),
  unique (incident_id, step_order)
);

create table public.test_results (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  incident_id uuid not null references public.incidents(id) on delete restrict,
  step_id uuid references public.troubleshooting_steps(id) on delete restrict,
  executed_by uuid references auth.users(id) on delete set null,
  test_name text not null check (char_length(test_name) between 1 and 180),
  result text not null check (result in ('passed','failed','blocked','not_run')),
  details text not null default '' check (char_length(details) <= 4000),
  executed_at timestamptz not null default now()
);

create table public.approval_records (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  incident_id uuid not null references public.incidents(id) on delete restrict,
  requested_by uuid not null references auth.users(id) on delete restrict,
  reviewed_by uuid references auth.users(id) on delete restrict,
  action_summary text not null check (char_length(action_summary) between 1 and 2000),
  risk text not null check (risk in ('low','medium','high')),
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled')),
  reason text not null default '' check (char_length(reason) <= 2000),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table public.incident_comments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  incident_id uuid not null references public.incidents(id) on delete restrict,
  author_id uuid not null references auth.users(id) on delete restrict,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

create table public.integrations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  provider text not null check (provider in ('groq','github','sentry','jira','grafana','prometheus','cloudwatch','azure_monitor','gcp_logging','servicenow','slack','teams','custom')),
  display_name text not null check (char_length(display_name) between 1 and 120),
  status text not null default 'not_connected' check (status in ('not_connected','pending','connected','error','disabled')),
  external_account_ref text,
  granted_scopes text[] not null default '{}',
  last_health_check_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, provider, display_name)
);

create table public.knowledge_articles (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  title text not null check (char_length(title) between 3 and 180),
  category public.incident_category not null,
  symptoms text not null default '' check (char_length(symptoms) <= 3000),
  verified_root_cause text not null default '' check (char_length(verified_root_cause) <= 3000),
  resolution_steps jsonb not null default '[]'::jsonb,
  preconditions text not null default '' check (char_length(preconditions) <= 2000),
  risk text not null default 'low' check (risk in ('low','medium','high')),
  required_permissions text[] not null default '{}',
  verification_procedure text not null default '' check (char_length(verification_procedure) <= 3000),
  author_id uuid references auth.users(id) on delete set null,
  reviewer_id uuid references auth.users(id) on delete set null,
  approval_status text not null default 'draft' check (approval_status in ('draft','in_review','approved','rejected','archived')),
  version integer not null default 1 check (version > 0),
  last_reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.audit_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null check (char_length(action) between 1 and 120),
  resource_type text not null check (char_length(resource_type) between 1 and 80),
  resource_id text,
  outcome text not null default 'success' check (outcome in ('success','denied','failure')),
  request_id text,
  redacted_metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_events_org_time_idx on public.audit_events(organization_id, created_at desc);

create or replace function public.current_user_org_id()
returns uuid language sql stable security definer set search_path = '' as $$
  select organization_id from public.profiles where id = (select auth.uid())
$$;
create or replace function public.current_user_role()
returns public.app_role language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id = (select auth.uid())
$$;
create or replace function public.is_workspace_manager()
returns boolean language sql stable security definer set search_path = '' as $$
  select coalesce(public.current_user_role() in ('manager','admin'), false)
$$;
revoke all on function public.current_user_org_id() from public;
revoke all on function public.current_user_role() from public;
revoke all on function public.is_workspace_manager() from public;
grant execute on function public.current_user_org_id() to authenticated;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.is_workspace_manager() to authenticated;

-- Row Level Security: organization boundary on every tenant-owned table.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['profiles','incidents','incident_events','diagnostic_findings','evidence_references','troubleshooting_steps','test_results','approval_records','incident_comments','integrations','knowledge_articles','audit_events'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
create policy "users read own organization" on public.organizations for select to authenticated using (id = (select public.current_user_org_id()));

create policy "profiles read same workspace" on public.profiles for select to authenticated using (organization_id = (select public.current_user_org_id()));
create policy "users update own profile or managers update workspace profile" on public.profiles for update to authenticated using (id = (select auth.uid()) or (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager()))) with check (organization_id = (select public.current_user_org_id()));
revoke update on public.profiles from anon, authenticated;
grant update (display_name) on public.profiles to authenticated;

create policy "incidents read same workspace" on public.incidents for select to authenticated using (organization_id = (select public.current_user_org_id()));
create policy "employees create incident in own workspace" on public.incidents for insert to authenticated with check (organization_id = (select public.current_user_org_id()) and created_by = (select auth.uid()));
create policy "agents update incidents in workspace" on public.incidents for update to authenticated using (organization_id = (select public.current_user_org_id()) and (select public.current_user_role()) in ('agent','manager','admin')) with check (organization_id = (select public.current_user_org_id()));
create policy "managers delete incidents in workspace" on public.incidents for delete to authenticated using (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager()));

-- Child table policies validate the parent incident's organization as well as the row tenant id.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['incident_events','diagnostic_findings','evidence_references','troubleshooting_steps','test_results','approval_records','incident_comments'] LOOP
    EXECUTE format('CREATE POLICY "workspace read %1$s" ON public.%1$I FOR SELECT TO authenticated USING (organization_id = (select public.current_user_org_id()) AND EXISTS (SELECT 1 FROM public.incidents i WHERE i.id = incident_id AND i.organization_id = (select public.current_user_org_id())))', t);
  END LOOP;
END $$;
create policy "agents add incident events" on public.incident_events for insert to authenticated with check (organization_id = (select public.current_user_org_id()) and actor_id = (select auth.uid()) and exists (select 1 from public.incidents i where i.id = incident_id and i.organization_id = (select public.current_user_org_id())));
create policy "agents add findings" on public.diagnostic_findings for insert to authenticated with check (organization_id = (select public.current_user_org_id()) and created_by = (select auth.uid()) and exists (select 1 from public.incidents i where i.id = incident_id and i.organization_id = (select public.current_user_org_id())));
create policy "agents add evidence refs" on public.evidence_references for insert to authenticated with check (organization_id = (select public.current_user_org_id()) and exists (select 1 from public.incidents i where i.id = incident_id and i.organization_id = (select public.current_user_org_id())));
create policy "agents manage steps" on public.troubleshooting_steps for all to authenticated using (organization_id = (select public.current_user_org_id()) and (select public.current_user_role()) in ('agent','manager','admin')) with check (organization_id = (select public.current_user_org_id()) and (select public.current_user_role()) in ('agent','manager','admin'));
create policy "agents add test results" on public.test_results for insert to authenticated with check (organization_id = (select public.current_user_org_id()) and executed_by = (select auth.uid()) and exists (select 1 from public.incidents i where i.id = incident_id and i.organization_id = (select public.current_user_org_id())));
create policy "managers manage approvals" on public.approval_records for all to authenticated using (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager())) with check (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager()));
create policy "workspace users comment" on public.incident_comments for insert to authenticated with check (organization_id = (select public.current_user_org_id()) and author_id = (select auth.uid()) and exists (select 1 from public.incidents i where i.id = incident_id and i.organization_id = (select public.current_user_org_id())));

create policy "workspace read integrations" on public.integrations for select to authenticated using (organization_id = (select public.current_user_org_id()));
create policy "managers manage integrations" on public.integrations for all to authenticated using (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager())) with check (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager()));
create policy "workspace read approved knowledge" on public.knowledge_articles for select to authenticated using (organization_id = (select public.current_user_org_id()) and (approval_status = 'approved' or (select public.is_workspace_manager())));
create policy "managers manage knowledge" on public.knowledge_articles for all to authenticated using (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager())) with check (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager()));
create policy "managers read audit" on public.audit_events for select to authenticated using (organization_id = (select public.current_user_org_id()) and (select public.is_workspace_manager()));

-- Append-only audit events for normal application roles; inserts are limited to the current workspace.
create policy "workspace append audit" on public.audit_events for insert to authenticated with check (organization_id = (select public.current_user_org_id()) and (actor_id is null or actor_id = (select auth.uid())));
revoke update, delete, truncate on public.audit_events from anon, authenticated;
revoke all on public.organizations from anon;
grant select on public.organizations to authenticated;
revoke all on public.audit_events from anon;

-- This migration intentionally does not create organizations or promote users automatically.
-- Bootstrap the first organization/profile via a trusted admin process; never trust a client-supplied role.
