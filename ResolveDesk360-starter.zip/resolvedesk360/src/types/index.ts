export type Severity = 'Critical' | 'High' | 'Medium' | 'Low';
export type IncidentStatus = 'Open' | 'Investigating' | 'Pending approval' | 'Resolved' | 'Closed';
export type ErrorCategory = 'API errors' | 'Database errors' | 'Data errors' | 'Authentication' | 'Network' | 'Deployment' | 'Configuration' | 'Performance' | 'Infrastructure' | 'Integration';
export interface Incident {
  id: string; title: string; category: ErrorCategory; severity: Severity; status: IncidentStatus;
  service: string; owner: string; createdAt: string; updatedAt: string; description: string;
  source: 'Synthetic demo' | 'Manual report'; evidence: string[]; events: { at: string; title: string; detail: string; kind: 'event'|'ai'|'human'|'test' }[];
}
export interface Diagnosis {
  summary: string;
  hypotheses: { cause: string; confidence: 'Low'|'Medium'|'High'; supportingEvidence: string[]; alternatives: string[]; nextCheck: string }[];
  steps: { title: string; detail: string; risk: 'Low'|'Medium'|'High'; expectedResult: string }[];
  disclaimer: string;
}
