# Security notes

## Data handling
- Treat logs, tickets, source snippets, webhook payloads and AI output as untrusted.
- Do not submit passwords, bearer tokens, API keys, private keys, personal data, or unnecessary source code to diagnosis.
- Demo records are synthetic. Manual incidents in demo mode are stored in browser localStorage; use only non-sensitive sample text.
- The Groq key belongs only in Supabase Edge Function secrets. Never expose it in Vite variables, browser storage, source control or client requests.

## Access control
- Use Supabase Auth with verified sessions and organization-scoped Row Level Security.
- Bootstrap organization membership and roles through a trusted process. Do not allow self-service role escalation.
- Test cross-tenant reads/writes, IDOR, privilege escalation and unauthenticated requests before launch.
- Use least-privilege credentials and read-only scopes wherever feasible.

## Limitations requiring remediation
- The current UI does not yet implement production authentication or real Supabase incident CRUD.
- Edge Function rate limiting is in-memory per isolate; use a durable, atomic shared limiter at the gateway/database layer for production.
- Redaction is heuristic and cannot guarantee removal of all sensitive data.
- Audit history needs hardened write paths and independent retention/monitoring to be tamper-resistant.
- Do not execute generated commands or production changes without constrained tools, explicit approval and actual verification tests.

Report security concerns privately to the project owner. Do not include real secrets in issue reports.
