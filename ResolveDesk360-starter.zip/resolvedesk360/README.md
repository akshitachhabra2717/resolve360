# ResolveDesk 360

**Evidence-led incident detection, root-cause investigation, safe resolution guidance, and verification.**

This repository is a production-oriented starter, not a claim of production certification. The UI runs in a clearly labelled local demo mode without credentials. It includes a React/TypeScript frontend, a Supabase schema/RLS migration, and a server-side Groq Edge Function. Production use requires configuring and testing your own Supabase project, auth/tenant bootstrap, API secrets, rate limiting, connectors, deployment and security controls.

## What's implemented

- Premium dark responsive command center and mobile layouts.
- Synthetic incident examples, incident search/filters, status changes, incident submission in local demo storage, timelines and detail panel.
- Demo-only diagnosis clearly labelled as offline example guidance; no claim of live AI or real verification.
- Optional Supabase client initialization from browser-safe variables.
- `ai-diagnose` Supabase Edge Function with JWT verification, user auth lookup, bounded request size, best-effort per-isolate throttling, simple sensitive-string redaction, timeout handling, structured JSON validation, and Groq requests from the server only.
- SQL migration for incidents, evidence references, diagnostics, steps, test results, approvals, integrations, knowledge articles and audit events, with organization-scoped RLS policies.
- PWA manifest and reduced-motion/keyboard-focus styling.

## Local development

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open the local URL shown by Vite. Without Supabase configuration, the app remains in demo mode. Incidents created in this mode are saved only to this browser's `localStorage`; do not enter real company or personal data into demo mode.

Build the static frontend:

```bash
npm run build
npm run preview
```

## Configure Supabase

1. Create a Supabase project.
2. Review `supabase/migrations/202610290001_initial_schema.sql` with a database/security reviewer and apply it to the intended project.
3. Bootstrap the first organization and profile through a trusted administrator workflow. The migration intentionally does not let a client create organizations or promote their own role. Ensure every authenticated user has a correctly assigned organization/profile before using RLS-protected tables.
4. In Supabase Auth, configure email verification, password policy, allowed redirect URLs, recovery flows and production site URL.
5. Set only the browser-safe project URL and publishable/anon key in `.env.local`:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```

Never put a Supabase secret/service-role key or Groq key in any `VITE_` variable or frontend bundle.

## Configure Groq securely

The current Groq Chat Completions API endpoint used here is `https://api.groq.com/openai/v1/chat/completions`. The Edge Function uses `GROQ_MODEL` so the selected model can be changed as provider availability changes. The example fallback is `llama-3.3-70b-versatile`; confirm it remains available in your Groq account before production use.

Install/configure Supabase CLI, link the project, then set server-side secrets (do not commit them):

```bash
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase secrets set GROQ_API_KEY=YOUR_GROQ_KEY GROQ_MODEL=llama-3.3-70b-versatile APP_ORIGIN=https://YOUR_APP_DOMAIN
npx supabase functions deploy ai-diagnose
```

The function requires a valid Supabase user JWT. It will reject local synthetic incident IDs. In this starter, the UI's sample/local incident workflow is deliberately not connected to a live production incident table; finish the authenticated incident CRUD flow before enabling real diagnosis. Review CORS (`APP_ORIGIN`), auth, rate limits, log redaction and provider data handling before use.

Official references:
- Groq API reference: https://console.groq.com/docs/api-reference
- Groq text generation: https://console.groq.com/docs/text-chat
- Supabase Edge Functions: https://supabase.com/docs/guides/functions
- Supabase Edge Function secrets: https://supabase.com/docs/guides/functions/secrets
- Supabase RLS: https://supabase.com/docs/guides/database/postgres/row-level-security

## Deploy frontend to Vercel

1. Push the project to a private GitHub repository if it contains organization-specific work.
2. Import the repository into Vercel.
3. Configure `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the Vercel project settings.
4. Set build command `npm run build`, output directory `dist`, and Node 20+.
5. Add a single-page-app rewrite if needed by your routing setup (this starter currently uses client-side view state rather than URL routes).
6. Add the final Vercel domain to Supabase Auth redirect URLs and `APP_ORIGIN`.
7. Test the deployed app, auth boundaries and function invocation. A deployment is not complete until these checks pass.

## Important production blockers to close before real company data

- Implement authenticated sign-in/sign-out and organization onboarding; the current frontend is a demo workspace and does not yet expose a full auth UI or real incident CRUD.
- Replace browser-local demo persistence with Supabase data access, tenant-safe server-side policies and integration tests.
- Review RLS and SQL migration with your actual role/tenant model. Test cross-tenant access and privilege escalation explicitly.
- Add durable shared rate limiting, quotas, abuse monitoring and request idempotency. The function's in-memory throttle is best-effort only and does not work as a global production limiter.
- Verify provider retention/training terms and company approval before sending any diagnostic content to Groq. Redaction is heuristic and is not a guarantee that all confidential data is removed.
- Implement real Sentry/GitHub/Jira connectors only with least-privilege credentials, signature verification, replay protection and connector-specific authorization.
- Add secrets scanning, dependency auditing, SAST, DAST, backups/restore drills, observability, incident response, privacy/retention controls and an independent security review.
- Add tested audit triggers or a trusted append-only audit writer; SQL grants alone are not a tamper-proof audit system against database owners.
- Add actual verification runners in isolated staging/sandbox environments. Never auto-execute AI-generated commands or mark a fix verified without recorded test results.
- Add real PWA icons and a service worker only after choosing the offline policy. This starter manifest intentionally avoids caching private incident data.
- Complete privacy policy, terms, applicable Indian DPDP Act/rules review and any sector-specific compliance before launch.

## Honest status

- Local UI: implemented; must be built and tested in your environment.
- Local demo mode: available without external credentials.
- Supabase schema and RLS: provided, not applied to your account or independently security-audited.
- Groq Edge Function: provided, not deployed or connected until you configure secrets and Supabase.
- Integrations: setup guidance only; not connected.
- Public URL: not deployed by this repository generation step.
- Security/compliance certification: not claimed.
